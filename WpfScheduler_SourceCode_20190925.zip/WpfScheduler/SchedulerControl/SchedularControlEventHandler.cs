﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;


namespace SchedulerControl
{
    
    public partial class SchedularControlEventHandler : INotifyPropertyChanged
    {
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool GetCursorPos(ref Win32Point pt);

        [StructLayout(LayoutKind.Sequential)]
        internal struct Win32Point
        {
            public Int32 X;
            public Int32 Y;
        };
        public static Point GetMousePosition()
        {
            Win32Point w32Mouse = new Win32Point();
            GetCursorPos(ref w32Mouse);
            return new Point(w32Mouse.X, w32Mouse.Y);
        }

        public delegate Point GetPosition(IInputElement element);
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(string propertyName) => PropertyChanged?.Invoke(null, new PropertyChangedEventArgs(propertyName));

        static bool IsLeftButtonClicked = false;
        static bool IsUpdateExisting = false;
        static bool IsUpdateFromStart = false;
        static bool IsUpdateFromEnd = false;
        static DataGridCell updatingCell = null;
        static DataGridCell lastMovingCell = null;
        static DataGridRow currentRow = null;
        static string dragStartUserId = string.Empty;
        static int StartTime = 0;
        
        static int minMove = 0;
        static int maxMove = 0;

        static DataGridCell DragStartCell;        
        static Nullable<Point> dragStartPoint = null;

        /*
        _receivedData[0] => User Id
        _receivedData[1] => Event Color
        _receivedData[2] => End Start Time (01:15-01:30 => return 00:15 value i.e.'75')
        _receivedData[3] => Start Time
        _receivedData[4] => Existing Event Start Time
        _receivedData[5] => Existing Event End Time
        _receivedData[6] => End Time
        */
        
        #region [DataGridCell Events]

        /// <summary>
        /// Mouse Enter DataGridCell (Display Tooltip)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SchedulerGrid_MouseEnter(object sender, MouseEventArgs e)
        {

            DependencyObject dep = (DependencyObject)e.OriginalSource;

            // iteratively traverse the visual tree
            while ((dep != null) && !(dep is DataGridCell) && !(dep is DataGridColumnHeader))
            {
                dep = VisualTreeHelper.GetParent(dep);
            }

            if (dep == null)
                return;

            if (dep is DataGridCell)
            {
                DataGridCell cell = dep as DataGridCell;

                object[] tagArray = (object[])cell.Tag;
                ToolTip toolTip = new ToolTip
                {
                    BorderThickness = new Thickness(1),
                    Margin = new Thickness(0),
                    Padding = new Thickness(0),
                    Content = new BorderToolTipControl(tagArray)
                };
                toolTip.UpdateLayout();
                toolTip.Visibility = Visibility.Visible;

                cell.ToolTip = toolTip;
                cell.UpdateLayout();

            }
        }

        /// <summary>
        /// Mouse Leave DataGridCell (Hide Tooltip)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SchedulerGrid_MouseLeave(object sender, MouseEventArgs e)
        {
            DependencyObject dep = (DependencyObject)e.OriginalSource;

            // iteratively traverse the visual tree
            while ((dep != null) && !(dep is DataGridCell) && !(dep is DataGridColumnHeader))
            {
                dep = VisualTreeHelper.GetParent(dep);
            }

            if (dep == null)
                return;
           
            if (dep is DataGridCell)
            {
                DataGridCell cell = dep as DataGridCell;
                if (((ToolTip)cell.ToolTip) != null)
                {
                    ((ToolTip)cell.ToolTip).Visibility = Visibility.Hidden;
                    ((ToolTip)cell.ToolTip).UpdateLayout();
                }

            }            
        }

        /// <summary>
        /// DataGridCell Mouse Button Down
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SchedulerCell_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            currentRow = null;
            DataGridCell currentCell = sender as DataGridCell;            

            var parentRow = VisualTreeHelper.GetParent(currentCell);
            while (parentRow != null && parentRow.GetType() != typeof(DataGridRow))
            {
                parentRow = VisualTreeHelper.GetParent(parentRow);
            }

            currentRow = (DataGridRow)parentRow;
            object[] tagArray = (object[])currentCell.Tag;

            //Check for drag drop
            int borderMinute = Convert.ToInt32(tagArray[2].ToString());
            if (currentCell.Cursor == Cursors.Hand && DateTime.TryParse((tagArray[4] ?? "").ToString(), CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal | DateTimeStyles.AllowWhiteSpaces, out DateTime stDate) && DateTime.TryParse((tagArray[5] ?? "").ToString(), CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal | DateTimeStyles.AllowWhiteSpaces, out DateTime enDate))
            {
                int TotalEndMinutes = (enDate.Minute + (enDate.Hour * 60));
                if (enDate > stDate && (enDate.Minute==0 && enDate.Hour == 0))
                {
                    TotalEndMinutes = 1440;
                }

                if (((stDate.Minute + (stDate.Hour * 60)) < borderMinute) && (TotalEndMinutes > borderMinute))
                {
                    int startColumnIndex = ((stDate.Minute + (stDate.Hour * 60)) / 15) + 1;
                    int currentColumnIndex = (Convert.ToInt16(tagArray[2]) / 15) + 1;

                    int endColumnIndex = (TotalEndMinutes / 15) + 1;
                    
                    for (int c = startColumnIndex; c <= endColumnIndex; c++)
                    {
                        DataGridCellsPresenter presenter = GetVisualChild<DataGridCellsPresenter>(currentRow);
                        var resultCell = presenter.ItemContainerGenerator.ContainerFromIndex(c) as DataGridCell;
                        if (resultCell != null)
                        {
                            resultCell.Background = Brushes.Transparent;
                            resultCell.UpdateLayout();
                        }
                    }
                    currentRow.UpdateLayout();
                    DragStartCell = currentCell;


                    Canvas canvas = new Canvas() {
                        Name= "SchedulerDynamicDragCanvas",
                        Cursor = Cursors.Hand,
                        AllowDrop=true
                    };

                    var parentGrid = VisualTreeHelper.GetParent(currentCell);
                    while (parentGrid != null && parentGrid.GetType() != typeof(Grid))
                    {
                        parentGrid = VisualTreeHelper.GetParent(parentGrid);
                    }

                    var parentDataGrid = VisualTreeHelper.GetParent(currentCell);
                    while (parentDataGrid != null && parentDataGrid.GetType() != typeof(DataGrid))
                    {
                        parentDataGrid = VisualTreeHelper.GetParent(parentDataGrid);
                    }

                    var p = e.GetPosition(parentDataGrid as IInputElement);
                    
                    System.Windows.Shapes.Rectangle rectangle = new System.Windows.Shapes.Rectangle() {
                        Fill = new SolidColorBrush((Color)tagArray[1]),
                        Width = (endColumnIndex - startColumnIndex) * currentCell.ActualWidth,
                        Height = currentCell.ActualHeight,
                        Opacity = 0.53,
                        AllowDrop = true,                        
                    };
                    rectangle.PreviewMouseLeftButtonDown +=  new MouseButtonEventHandler((object senderR, MouseButtonEventArgs eR) => 
                    {
                        var element = (System.Windows.Shapes.Rectangle)senderR;
                        dragStartPoint = eR.GetPosition(element);
                        element.CaptureMouse();
                    });

                    rectangle.MouseMove += new MouseEventHandler((object senderR, MouseEventArgs eR) => 
                    {
                        if (dragStartPoint != null && eR.LeftButton == MouseButtonState.Pressed)
                        {
                            var element = (System.Windows.Shapes.Rectangle)senderR;
                            var p2 = eR.GetPosition(element.Parent as Canvas);
                            Canvas.SetLeft(element, p2.X - dragStartPoint.Value.X);
                            Canvas.SetTop(element, p2.Y - dragStartPoint.Value.Y);
                        }
                    });
                    rectangle.MouseLeftButtonUp += new MouseButtonEventHandler((object senderR, MouseButtonEventArgs eR) => 
                    {
                        var element = (System.Windows.Shapes.Rectangle)senderR;

                        var p2 = eR.GetPosition(element.Parent as Canvas);
                        var newLeft = Canvas.GetLeft(element);

                        element.ReleaseMouseCapture();

                        DataGridCell TargetCell =  GetCurrentRowIndex(parentDataGrid as DataGrid, e.GetPosition);

                        //Remove Added drag canvas from the page
                        #region [Remove Added drag canvas from the page]
                        //var parentGrid = VisualTreeHelper.GetParent(currentCell);
                        while (parentGrid != null && parentGrid.GetType() != typeof(Grid))
                        {
                            parentGrid = VisualTreeHelper.GetParent(parentGrid);
                        }
                        if (parentGrid != null)
                        {
                            var existingCanvas = FindChild<Canvas>(parentGrid, "SchedulerDynamicDragCanvas");
                            if (existingCanvas != null)
                            {
                                ((Grid)parentGrid).Children.Remove(existingCanvas);
                                ((Grid)parentGrid).UpdateLayout();
                            }
                        }
                        #endregion

                        if (TargetCell != null)
                        {
                            var parentRowTarget = VisualTreeHelper.GetParent(TargetCell);
                            while (parentRowTarget != null && parentRowTarget.GetType() != typeof(DataGridRow))
                            {
                                parentRowTarget = VisualTreeHelper.GetParent(parentRowTarget);
                            }

                            var targetRow = (DataGridRow)parentRowTarget;
                            object[] tagArrayTarget = (object[])TargetCell.Tag;

                            //Start Time
                            int StartMinutes = Convert.ToInt16(tagArrayTarget[2]) - 15;
                            StartMinutes = (StartMinutes < 0) ? 0 : StartMinutes;
                            //End Time
                            DateTime.TryParse((tagArray[5] ?? "").ToString(), CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal | DateTimeStyles.AllowWhiteSpaces, out DateTime existingEndDate);
                            DateTime.TryParse((tagArray[4] ?? "").ToString(), CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal | DateTimeStyles.AllowWhiteSpaces, out DateTime existingStartDate);
                            int EndMinutes = StartMinutes + Convert.ToInt16(existingEndDate.Subtract(existingStartDate).TotalMinutes);

                            if (EndMinutes >= 1440)
                            {
                                EndMinutes = 1440;
                                StartMinutes = EndMinutes - Convert.ToInt16(existingEndDate.Subtract(existingStartDate).TotalMinutes);
                            }
                            int startColumnIndexTarget = (StartMinutes / 15) + 1;
                            int endColumnIndexTarget = (EndMinutes / 15) + 1;



                            for (int c = startColumnIndexTarget; c < endColumnIndexTarget; c++)
                            {
                                DataGridCellsPresenter presenter = GetVisualChild<DataGridCellsPresenter>(targetRow);
                                var resultCell = presenter.ItemContainerGenerator.ContainerFromIndex(c) as DataGridCell;
                                if (resultCell != null)
                                {
                                    resultCell.Background = new SolidColorBrush((Color)tagArrayTarget[1]);
                                    resultCell.UpdateLayout();
                                }
                            }
                            targetRow.UpdateLayout();

                            ((DataGrid)parentDataGrid).RaiseEvent(new RoutedEventArgs(SchedulerCustomControl.OnDragControlMouseLeftButtonUpEvent, new object[] { DragStartCell, TargetCell }));
                        }
                        else
                        {
                            //((DataGrid)parentDataGrid).RaiseEvent(new RoutedEventArgs(SchedulerCustomControl.OnDragControlMouseLeftButtonUpEvent, null));
                            for (int c = startColumnIndex; c < endColumnIndex; c++)
                            {
                                DataGridCellsPresenter presenter = GetVisualChild<DataGridCellsPresenter>(currentRow);
                                var resultCell = presenter.ItemContainerGenerator.ContainerFromIndex(c) as DataGridCell;
                                if (resultCell != null)
                                {
                                    resultCell.Background = new SolidColorBrush((Color)tagArray[1]);
                                    resultCell.UpdateLayout();
                                }
                            }
                            currentRow.UpdateLayout();
                        }

                        StartTime = 0;
                        minMove = 0; maxMove = 0;
                        //SecondLastTime = 0;
                        IsLeftButtonClicked = false;                        
                        IsUpdateExisting = false;
                        IsUpdateFromStart = false;
                        IsUpdateFromEnd = false;
                        dragStartUserId = string.Empty;
                        currentRow = null;
                        updatingCell = null;
                        lastMovingCell = null;
                        DragStartCell = null;
                        dragStartPoint = null;

                    });

                    canvas.Children.Add(rectangle);

                    Canvas.SetLeft(rectangle, (p.X > 20)? p.X -20: p.X);
                    Canvas.SetTop(rectangle, (p.Y > 20) ? p.Y - 20 : p.Y);

                    if (parentGrid != null)
                    {
                        var existingCanvas = FindChild<Canvas>(parentGrid, "SchedulerDynamicDragCanvas");
                        if (existingCanvas != null)
                        {
                            ((Grid)parentGrid).Children.Remove(existingCanvas);
                            ((Grid)parentGrid).UpdateLayout();
                        }

                        ((Grid)parentGrid).Children.Add(canvas);
                        rectangle.CaptureMouse();
                        //Call rectangle mouse left button down event
                        Rectangle_PreviewMouseLeftButtonDown(rectangle, e);
                    }

                }

            }
            //For Resize or Create New Event
            else
            {
                IsLeftButtonClicked = true;


                if (tagArray.Length > 0)
                    dragStartUserId = tagArray[0].ToString();

                Brush brush = null;
                try
                {
                    brush = new SolidColorBrush((Color)tagArray[1]);
                }
                catch
                {
                    brush = Brushes.Navy;
                }

                StartTime = Convert.ToInt16(tagArray[2]);

                //Check for existing event
                if (!DateTime.TryParse((tagArray[4] ?? "").ToString(), CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal | DateTimeStyles.AllowWhiteSpaces, out DateTime sDate))
                {

                }
                else if (!DateTime.TryParse((tagArray[5] ?? "").ToString(), CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal | DateTimeStyles.AllowWhiteSpaces, out DateTime eDate))
                {

                }
                else
                {
                    eDate = eDate.AddMinutes(-15);
                    if (((sDate.Minute + (sDate.Hour * 60)) <= borderMinute) && ((eDate.Minute + (eDate.Hour * 60)) >= borderMinute))
                    {
                        updatingCell = currentCell;
                        StartTime = sDate.Minute + (sDate.Hour * 60);
                        if ((sDate.Minute + (sDate.Hour * 60)) == borderMinute)
                        {
                            IsUpdateExisting = true;
                            IsUpdateFromStart = true;
                            IsUpdateFromEnd = false;
                            maxMove = (eDate.Minute + (eDate.Hour * 60));
                        }
                        else if ((eDate.Minute + (eDate.Hour * 60)) == borderMinute)
                        {
                            IsUpdateExisting = true;
                            IsUpdateFromStart = false;
                            IsUpdateFromEnd = true;
                            maxMove = (eDate.Minute + (eDate.Hour * 60));
                        }
                        else
                        {
                            IsLeftButtonClicked = false;
                            IsUpdateExisting = false;
                            IsUpdateFromStart = false;
                            IsUpdateFromEnd = false;
                            updatingCell = null;
                            lastMovingCell = null;
                            DragStartCell = null;
                            currentRow = null;
                            dragStartUserId = string.Empty;
                            brush = null;
                            StartTime = minMove = maxMove = 0;
                            return;
                        }
                    }
                }

                currentCell.Background = brush;
                brush = null;
                currentCell.UpdateLayout();


                minMove = StartTime;
                if (!IsUpdateExisting)
                    maxMove = StartTime;
            }
        }

        /// <summary>
        /// Call PreviewMouseLeftButtonDown event on dynamically added rectangle
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Rectangle_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var element = (System.Windows.Shapes.Rectangle)sender;
            dragStartPoint = e.GetPosition(element);
            element.CaptureMouse();
        }

        /// <summary>
        /// DataGridCell MouseLeftButtonMove
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SchedulerCell_MouseLeftButtonMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                if (IsLeftButtonClicked && currentRow != null)
                {
                    Mouse.SetCursor(Cursors.SizeWE);
                    DataGridCellsPresenter presenter = GetVisualChild<DataGridCellsPresenter>(currentRow);
                    DataGridCell currentMouseCell = sender as DataGridCell;
                    object[] mouseTagArray = (object[])currentMouseCell.Tag;

                    DataGridCell currentCell = presenter.ItemContainerGenerator.ContainerFromIndex((Convert.ToInt16(mouseTagArray[2]) / 15) + 1) as DataGridCell;


                    object[] tagArray = (object[])currentCell.Tag;

                    if (tagArray[0].ToString() == dragStartUserId)
                    {
                        Brush brush = null;
                        try
                        {
                            brush = new SolidColorBrush((Color)tagArray[1]);
                        }
                        catch
                        {
                            brush = Brushes.Navy;
                        }
                        
                        int NewStartTime = 0;
                        int EndTime = 0;

                        if (IsUpdateExisting)
                        {
                            DateTime eDate = Convert.ToDateTime(((object[])updatingCell.Tag)[5]).AddMinutes(-15);
                            if (IsUpdateFromStart)
                            {
                                //Decrease Start time
                                if (StartTime >= Convert.ToInt16(tagArray[2]))
                                {
                                    StartTime = Convert.ToInt16(tagArray[2]);
                                    EndTime = (eDate.Minute + (eDate.Hour * 60));
                                }
                                //Increase Start time
                                else if (StartTime < Convert.ToInt16(tagArray[2]))
                                {
                                    StartTime = Convert.ToInt16(tagArray[2]);
                                    EndTime = (eDate.Minute + (eDate.Hour * 60));
                                }
                            }
                            if (IsUpdateFromEnd)
                            {
                                //Decrease End time
                                if ((eDate.Minute + (eDate.Hour * 60)) >= Convert.ToInt16(tagArray[2]))
                                {
                                    EndTime = Convert.ToInt16(tagArray[2]);
                                }
                                //Increase End time
                                else if ((eDate.Minute + (eDate.Hour * 60)) < Convert.ToInt16(tagArray[2]))
                                {
                                    EndTime = Convert.ToInt16(tagArray[2]);
                                }
                            }
                            NewStartTime = StartTime;
                        }
                        else
                        {
                            NewStartTime = StartTime;
                            EndTime = Convert.ToInt16(tagArray[2]);
                        }


                        if (NewStartTime > EndTime)
                        {
                            //Swap start & end time
                            NewStartTime = NewStartTime + EndTime;
                            EndTime = NewStartTime - EndTime;
                            NewStartTime = NewStartTime - EndTime;
                        }

                        if (NewStartTime < minMove)
                            minMove = NewStartTime;
                        if (EndTime > maxMove)
                            maxMove = EndTime;
                        
                        int startColumnIndex = (NewStartTime / 15) + 1;
                        int endColumnIndex = (EndTime / 15) + 1;
                        int minColumnIndex = (minMove / 15) + 1;
                        int maxColumnIndex = (maxMove / 15) + 1;

                        for (int c = minColumnIndex; c <= maxColumnIndex; c++)
                        {
                            var resultCell = presenter.ItemContainerGenerator.ContainerFromIndex(c) as DataGridCell;
                            if (resultCell != null)
                            {
                                resultCell.Background = (c >= startColumnIndex && c <= endColumnIndex) ? brush : Brushes.Transparent;
                                //resultCell.UpdateLayout();                                
                            }
                        }


                        brush = null;

                        tagArray[3] = StartTime;
                        //currentCell.Tag = tagArray;
                        //currentCell.UpdateLayout();
                        lastMovingCell = currentCell;
                    }
                    else
                    {
                        StartTime = 0;
                        IsLeftButtonClicked = false;
                        IsUpdateExisting = false;
                        IsUpdateFromStart = false;
                        IsUpdateFromEnd = false;
                        dragStartUserId = string.Empty;
                        updatingCell = null;
                        lastMovingCell = null;
                        DragStartCell = null;
                        currentRow = null;
                    }
                }
            }
        }

        /// <summary>
        /// DataGridCell MouseLeftButtonUp event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SchedulerCell_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            Mouse.SetCursor(Cursors.Arrow);
            if (IsLeftButtonClicked && currentRow != null)
            {
                DataGridCellsPresenter presenter = GetVisualChild<DataGridCellsPresenter>(currentRow);
                DataGridCell currentMouseCell = sender as DataGridCell;
                object[] mouseTagArray = (object[])currentMouseCell.Tag;

                DataGridCell currentCell = presenter.ItemContainerGenerator.ContainerFromIndex((Convert.ToInt16(mouseTagArray[2]) / 15) + 1) as DataGridCell;

                object[] tagArray = (object[])currentCell.Tag;

                if (tagArray.Length > 0)
                    dragStartUserId = tagArray[0].ToString();
                try
                {                    
                    if (tagArray.Length > 1)
                    {
                        Brush brush = null;
                        try
                        {
                            brush = new SolidColorBrush((Color)tagArray[1]);
                        }
                        catch
                        {
                            brush = Brushes.Navy;
                        }
                        currentCell.Background = brush;


                        int NewStartTime = 0;
                        int EndTime = 0;

                        if (IsUpdateExisting)
                        {
                            DateTime eDate = Convert.ToDateTime(((object[])updatingCell.Tag)[5]).AddMinutes(-15);
                            if (IsUpdateFromStart)
                            {
                                //Decrease Start time
                                if (StartTime >= Convert.ToInt16(tagArray[2]))
                                {
                                    StartTime = Convert.ToInt16(tagArray[2]);
                                    EndTime = (eDate.Minute + (eDate.Hour * 60));
                                }
                                //Increase Start time
                                else if (StartTime < Convert.ToInt16(tagArray[2]))
                                {
                                    StartTime = Convert.ToInt16(tagArray[2]);
                                    EndTime = (eDate.Minute + (eDate.Hour * 60));
                                }
                            }
                            if (IsUpdateFromEnd)
                            {
                                //Decrease End time
                                if ((eDate.Minute + (eDate.Hour * 60)) >= Convert.ToInt16(tagArray[2]))
                                {
                                    EndTime = Convert.ToInt16(tagArray[2]);
                                }
                                //Increase End time
                                else if ((eDate.Minute + (eDate.Hour * 60)) < Convert.ToInt16(tagArray[2]))
                                {
                                    EndTime = Convert.ToInt16(tagArray[2]);
                                }
                            }
                            NewStartTime = StartTime;
                        }
                        else
                        {
                            NewStartTime = StartTime;
                            EndTime = Convert.ToInt16(tagArray[2]);
                        }

                        //Set All cells bg color (startTime to End Time)
                        
                        if (NewStartTime > EndTime)
                        {
                            //Swap start & end time
                            NewStartTime = NewStartTime + EndTime;
                            EndTime = NewStartTime - EndTime;
                            NewStartTime = NewStartTime - EndTime;
                        }
                        tagArray[6] = EndTime + 15;
                        tagArray[3] = NewStartTime;

                        if (NewStartTime < minMove)
                            minMove = NewStartTime;
                        if (EndTime > maxMove)
                            maxMove = EndTime;

                        int startColumnIndex = (NewStartTime / 15) + 1;
                        int endColumnIndex = (EndTime / 15) + 1;
                        int minColumnIndex = (minMove / 15) + 1;
                        int maxColumnIndex = (maxMove / 15) + 1;

                        //For Single Event Only
                        for (int c = 1; c <= 96; c++)
                        {
                            //DataGridCellsPresenter presenter = GetVisualChild<DataGridCellsPresenter>(currentRow);
                            var resultCell = presenter.ItemContainerGenerator.ContainerFromIndex(c) as DataGridCell;
                            if (resultCell != null)
                            {
                                if (c >= minColumnIndex && c <= maxColumnIndex)
                                    resultCell.Background = (c >= startColumnIndex && c <= endColumnIndex) ? brush : Brushes.Transparent;
                                else
                                    resultCell.Background = Brushes.Transparent;
                                resultCell.UpdateLayout();
                            }
                        }

                        brush = null;
                    }
                }
                catch
                {
                    currentCell.Background = Brushes.Navy;
                }                
                currentCell.Tag = tagArray;
                currentCell.UpdateLayout();

                //Remove Added drag canvas from the page
                #region [Remove Added drag canvas from the page]
                var parentGrid = VisualTreeHelper.GetParent(currentCell);
                while (parentGrid != null && parentGrid.GetType() != typeof(Grid))
                {
                    parentGrid = VisualTreeHelper.GetParent(parentGrid);
                }
                if (parentGrid != null)
                {
                    var existingCanvas = FindChild<Canvas>(parentGrid, "SchedulerDynamicDragCanvas");
                    if (existingCanvas != null)
                    {
                        ((Grid)parentGrid).Children.Remove(existingCanvas);
                        ((Grid)parentGrid).UpdateLayout();
                    }
                }
                #endregion

                var parentDataGrid = VisualTreeHelper.GetParent(currentCell);
                while (parentDataGrid != null && parentDataGrid.GetType() != typeof(DataGrid))
                {
                    parentDataGrid = VisualTreeHelper.GetParent(parentDataGrid);
                }

                if (parentDataGrid != null)
                {
                    ((DataGrid)parentDataGrid).RaiseEvent(new RoutedEventArgs(SchedulerCustomControl.on_BorderMouseLeftButtonUpEvent, currentCell));
                }

            }

            StartTime = 0;
            minMove = 0; maxMove = 0;
            IsLeftButtonClicked = false;
            IsUpdateExisting = false;
            IsUpdateFromStart = false;
            IsUpdateFromEnd = false;
            dragStartUserId = string.Empty;
            currentRow = null;
            updatingCell = null;
            lastMovingCell = null;
        }

        /// <summary>
        /// DataGridCell MouseLeftButtonUp event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SchedulerGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (IsLeftButtonClicked && lastMovingCell != null)
            {
                SchedulerCell_MouseLeftButtonUp(lastMovingCell, e);
            }
        }


        private bool GetMouseTargetRow(Visual theTarget, GetPosition position)
        {
            Rect rect = VisualTreeHelper.GetDescendantBounds(theTarget);
            Point point = position((IInputElement)theTarget);
            return rect.Contains(point);
        }

        private DataGridRow GetRowItem(DataGrid dataGrid, int index)
        {
            if (dataGrid.ItemContainerGenerator.Status != GeneratorStatus.ContainersGenerated)
                return null;
            return dataGrid.ItemContainerGenerator.ContainerFromIndex(index) as DataGridRow;
        }

        private DataGridCell GetCurrentRowIndex(DataGrid dataGrid, GetPosition pos)
        {
            //int curIndex = -1;
            for (int i = 0; i < dataGrid.Items.Count; i++)
            {
                DataGridRow itm = GetRowItem(dataGrid, i);
                if (itm != null)
                {
                    if (GetMouseTargetRow(itm, pos))
                    {
                        DataGridCellsPresenter presenter = GetVisualChild<DataGridCellsPresenter>(itm);
                        DataGridCell result;
                        for (int c = 96; c > 0; c--)
                        {
                            result = presenter.ItemContainerGenerator.ContainerFromIndex(c) as DataGridCell;
                            if (result != null)
                            {
                                if (GetMouseTargetRow(result, pos))
                                {
                                    return result;
                                }
                            }
                        }
                        return null;
                        //curIndex = i;
                        //break;
                    }
                }
            }
            return null;
        }

        #endregion

        public static DataGridCell TryToFindGridCell(DataGrid grid, DataGridCellInfo cellInfo)
        {
            DataGridCell result = null;
            DataGridRow row = (DataGridRow)grid.ItemContainerGenerator.ContainerFromItem(cellInfo.Item);
            if (row != null)
            {
                int columnIndex = grid.Columns.IndexOf(cellInfo.Column);
                if (columnIndex > -1)
                {
                    DataGridCellsPresenter presenter = GetVisualChild<DataGridCellsPresenter>(row);
                    result = presenter.ItemContainerGenerator.ContainerFromIndex(columnIndex) as DataGridCell;
                }
            }
            return result;
        }

        public static T GetVisualChild<T>(Visual parent) where T : Visual
        {
            T child = default(T);
            int numVisuals = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < numVisuals; i++)
            {
                Visual v = (Visual)VisualTreeHelper.GetChild(parent, i);
                child = v as T;
                if (child == null)
                {
                    child = GetVisualChild<T>(v);
                }
                if (child != null)
                {
                    break;
                }
            }
            return child;
        }

        /// <summary>
        /// Find child element
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="parent"></param>
        /// <param name="childName"></param>
        /// <returns></returns>
        public static T FindChild<T>(DependencyObject parent, string childName) where T : DependencyObject
        {
            // Confirm parent and childName are valid. 
            if (parent == null) return null;

            T foundChild = null;

            int childrenCount = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < childrenCount; i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                // If the child is not of the request child type child
                T childType = child as T;
                if (childType == null)
                {
                    // recursively drill down the tree
                    foundChild = FindChild<T>(child, childName);

                    // If the child is found, break so we do not overwrite the found child. 
                    if (foundChild != null) break;
                }
                else if (!string.IsNullOrEmpty(childName))
                {
                    var frameworkElement = child as FrameworkElement;
                    // If the child's name is set for search
                    if (frameworkElement != null && frameworkElement.Name == childName)
                    {
                        // if the child's name is of the request name
                        foundChild = (T)child;
                        break;
                    }
                }
                else
                {
                    // child element found.
                    foundChild = (T)child;
                    break;
                }
            }

            return foundChild;
        }
    }
}
