﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace SchedulerControl
{
    /// <summary>
    /// User Detail class
    /// </summary>
    public class UserData : INotifyPropertyChanged
    {
        private int _UserId;
        public int UserId { get { return _UserId; } set { _UserId = value; OnPropertyChanged(); } }
        private string _Name { get; set; }
        public string Name { get { return _Name; } set { _Name = value; OnPropertyChanged(); } }
        private byte[] _UserPhoto;
        public byte[] UserPhoto { get { return _UserPhoto; } set { _UserPhoto = value; OnPropertyChanged(); } }
        public BitmapSource UserImageSource { get { return UserPhoto != null ? UserPhoto.ConvertBytesToBitmapImage() : null; } }
        private DateTime? _EventStartTime;
        public DateTime? EventStartTime { get { return _EventStartTime; } set { _EventStartTime = value; OnPropertyChanged(); } }
        private DateTime? _EventEndTime;
        public DateTime? EventEndTime { get { return _EventEndTime; } set { _EventEndTime = value; OnPropertyChanged(); } }
        private string _EventDescription;
        public string EventDescription { get { return _EventDescription; } set { _EventDescription = value; OnPropertyChanged(); } }
        //public string EventColor { get; set; }
        private Color _EventColor;
        public Color EventColor { get { return _EventColor; } set { _EventColor = value; OnPropertyChanged(); } }

        public event PropertyChangedEventHandler PropertyChanged = (sender, e) => { };

        /// <summary>
        /// Call this to fire a <see cref="PropertyChanged"/> event
        /// </summary>
        /// <param name="name"></param>
        public void OnPropertyChanged([CallerMemberName] String propertyName = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        #region Command Helpers

        /// <summary>
        /// Runs a command if the updating flag is not set.
        /// If the flag is true (indicating the function is already running) then the action is not run.
        /// If the flag is false (indicating no running function) then the action is run.
        /// Once the action is finished if it was run, then the flag is reset to false
        /// </summary>
        /// <param name="updatingFlag">The boolean property flag defining if the command is already running</param>
        /// <param name="action">The action to run if the command is not already running</param>
        /// <returns></returns>
        protected async Task RunCommandAsync(Expression<Func<bool>> updatingFlag, Func<Task> action)
        {
            // Check if the flag property is true (meaning the function is already running)
            if (updatingFlag.GetPropertyValue())
                return;

            // Set the property flag to true to indicate we are running
            updatingFlag.SetPropertyValue(true);

            try
            {
                // Run the passed in action
                await action();
            }
            finally
            {
                // Set the property flag back to false now it's finished
                updatingFlag.SetPropertyValue(false);
            }
        }

        #endregion
    }



    public static class ImageExtensions
    {

        /// <summary>
        /// Compiles an expression and gets the functions return value
        /// </summary>
        /// <typeparam name="T">The type of return value</typeparam>
        /// <param name="lamba">The expression to compile</param>
        /// <returns></returns>
        public static T GetPropertyValue<T>(this Expression<Func<T>> lamba)
        {
            return lamba.Compile().Invoke();
        }

        /// <summary>
        /// Sets the underlying properties value to the given value
        /// from an expression that contains the property
        /// </summary>
        /// <typeparam name="T">The type of value to set</typeparam>
        /// <param name="lamba">The expression</param>
        /// <param name="value">The value to set the property to</param>
        public static void SetPropertyValue<T>(this Expression<Func<T>> lamba, T value)
        {
            // Converts a lamba () => some.Property, to some.Property
            var expression = (lamba as LambdaExpression).Body as MemberExpression;

            // Get the property information so we can set it
            var propertyInfo = (PropertyInfo)expression.Member;
            var target = System.Linq.Expressions.Expression.Lambda(expression.Expression).Compile().DynamicInvoke();

            // Set the property value
            propertyInfo.SetValue(target, value);

        }

        /// <summary>
        /// Convert byte[] to BitMap Image
        /// </summary>
        /// <param name="imageBytes">byte[], whicj you want to convert</param>
        /// <returns></returns>
        public static BitmapImage ConvertBytesToBitmapImage(this byte[] imageBytes)
        {
            if (imageBytes == null || imageBytes.Length == 0) return null;
            var image = new BitmapImage();
            using (var mem = new MemoryStream(imageBytes))
            {
                mem.Position = 0;
                image.BeginInit();
                image.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.UriSource = null;
                image.StreamSource = mem;
                image.EndInit();
            }
            image.Freeze();
            return image;
        }
    }
}
