﻿using SchedulerControl;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace WpfScheduler
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {

        //public static class Commands
        //{
        //    public static RoutedCommand MouseLeftButtonDown = new RoutedCommand("Border_MouseLeftButtonDown", typeof(Commands));
        //}

        private ObservableCollection<UserData> _Items;

        public ObservableCollection<UserData> Items
        {
            get
            {
                if (_Items == null)
                    _Items = new ObservableCollection<UserData>();
                return _Items;
            }
            set
            {
                _Items = value;
                OnPropertyChanged(nameof(Items));
            }
        }
        public MainWindowViewModel()
        {
            //DataGridMouseLeftButtonDown = new Action<object, MouseButtonEventArgs>(DataGridMouseLeftButtonDownExecute);
            Items = new ObservableCollection<UserData>
            {
                new UserData
                {
                    Name = "Vinayak",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Navy,
                    EventDescription = "My Event",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 45, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 02, 00, 0),
                    UserId = 1
                },
                new UserData
                {
                    Name = "Mahesh",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Green,
                    EventDescription = "My Event - 2",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 01, 45, 0),
                    UserId = 1
                },
                new UserData
                {
                    Name = "Ramesh",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Gray,
                    EventDescription = "My Event - 3",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 00, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 01, 00, 0),
                    UserId = 1
                }
            };
            OnPropertyChanged(nameof(Items));

            //StaffScheduleControl_on_Click = new RoutedEventHandler<object,>
        }

        public RoutedEventHandler StaffScheduleControl_on_Click { get; set; }

        private void StaffScheduleControl_on_ClickExecute(object sender, MouseButtonEventArgs e)
        {

        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(string propertyName) => PropertyChanged?.Invoke(null, new PropertyChangedEventArgs(propertyName));
    }
}
