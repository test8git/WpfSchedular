﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SchedulerControl
{
    /// <summary>
    /// Interaction logic for BorderToolTipControl.xaml
    /// </summary>
    public partial class BorderToolTipControl : UserControl
    {         
        public static DependencyProperty ColumnValueNameProperty =
        DependencyProperty.Register("ColumnValueName", typeof(object), typeof(BorderToolTipControl), new UIPropertyMetadata("", OnColumnValueChanged));

        private static void OnColumnValueChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            
            var _ct = (BorderToolTipControl)d;
            int val = Convert.ToInt16(e.NewValue.ToString());

            int minutes = val % 60;
            int hours = val / 60;

            if (_ct.FindName("minuteHand") is RotateTransform _minHand)
                _minHand.Angle = minutes * 6;
            if (_ct.FindName("hourHand") is RotateTransform _hourHand)
                _hourHand.Angle = (hours * 30) + (minutes * 0.5);

            if (_ct.FindName("TxtTime") is TextBlock _txt)
                _txt.Text = hours.ToString().PadLeft(2, '0') + ":" + minutes.ToString().PadLeft(2, '0');
        }

        public object ColumnValueName
        {
            get { return (object)GetValue(ColumnValueNameProperty); }
            set { SetValue(ColumnValueNameProperty, value); }
        }

        public BorderToolTipControl()
        {
            InitializeComponent();
        }
        public BorderToolTipControl(object[] borderData)
        {
            InitializeComponent();

            /**For Multi Binding*/
            bool IsEventExist = true;
                                        
            if (!DateTime.TryParse((borderData[4] ?? "").ToString(), CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal | DateTimeStyles.AllowWhiteSpaces, out DateTime sDate))
            {
                IsEventExist = false;
                PanelTo.Visibility = Visibility.Collapsed;
            }
            if (!DateTime.TryParse((borderData[5] ?? "").ToString(), CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal | DateTimeStyles.AllowWhiteSpaces, out DateTime eDate))
            {
                IsEventExist = false;
                PanelTo.Visibility = Visibility.Collapsed;
            }
            int borderMinute = Convert.ToInt32(borderData[2].ToString());

            //Event exist for the user
            if (IsEventExist)
            {
                if (((sDate.Minute + (sDate.Hour * 60)) <= borderMinute) && ((eDate.AddMinutes(-15).Minute + (eDate.AddMinutes(-15).Hour * 60)) >= borderMinute))
                {
                    PanelTo.Visibility = Visibility.Visible;

                    minuteHand.Angle = sDate.Minute * 6;
                    hourHand.Angle = (sDate.Hour * 30) + (sDate.Minute * 0.5);
                    TxtTime.Text = sDate.Hour.ToString().PadLeft(2, '0') + ":" + sDate.Minute.ToString().PadLeft(2, '0');

                    minuteHandTo.Angle = eDate.Minute * 6;
                    hourHandTo.Angle = (eDate.Hour * 30) + (eDate.Minute * 0.5);

                    TxtTimeTo.Text = eDate.Hour.ToString().PadLeft(2, '0') + ":" + eDate.Minute.ToString().PadLeft(2, '0');

                }
                else
                {
                    PanelTo.Visibility = Visibility.Collapsed;

                    int minutes = borderMinute % 60;
                    int hours = borderMinute / 60;

                    minuteHand.Angle = minutes * 6;
                    hourHand.Angle = (hours * 30) + (minutes * 0.5);
                    TxtTime.Text = hours.ToString().PadLeft(2, '0') + ":" + minutes.ToString().PadLeft(2, '0');
                }
            }
            else
            {
                int minutes = borderMinute % 60;
                int hours = borderMinute / 60;

                minuteHand.Angle = minutes * 6;
                hourHand.Angle = (hours * 30) + (minutes * 0.5);
                TxtTime.Text = hours.ToString().PadLeft(2, '0') + ":" + minutes.ToString().PadLeft(2, '0');
            }
        }
    }
}
