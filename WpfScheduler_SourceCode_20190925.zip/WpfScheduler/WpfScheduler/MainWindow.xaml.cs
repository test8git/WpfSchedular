﻿using SchedulerControl;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Threading;

namespace WpfScheduler
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool GetCursorPos(ref Win32Point pt);

        [StructLayout(LayoutKind.Sequential)]
        internal struct Win32Point
        {
            public Int32 X;
            public Int32 Y;
        };
        /// <summary>
        /// Get Mouse Current Position
        /// </summary>
        /// <returns></returns>
        public static Point GetMousePosition()
        {
            Win32Point w32Mouse = new Win32Point();
            GetCursorPos(ref w32Mouse);
            return new Point(w32Mouse.X, w32Mouse.Y);
        }

        public CollectionViewSource ViewSource { get; set; }
        public ObservableCollection<UserData> ItemsList { get; set; }

        //{
        //    get
        //    {
        //        if (_Items == null)
        //            _Items = new ObservableCollection<UserData>();
        //        return _Items;
        //    }
        //    set
        //    {
        //        _Items = value;
        //        OnPropertyChanged(nameof(Items));
        //    }
        //}
        public MainWindow()
        {
            
            InitializeComponent();
            this.Width = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width;            
            this.Height = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height-50;
            StaffScheduleDataGrid.Height = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height - 50;
            //DataContext = this;
            
            ItemsList = new ObservableCollection<UserData>
            {
                new UserData
                {
                    Name = "Vinayak",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Navy,
                    EventDescription = "My Event",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 45, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 02, 00, 0),
                    UserId = 1
                },
                new UserData
                {
                    Name = "Mahesh",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Green,
                    EventDescription = "My Event - 2",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 01, 45, 0),
                    UserId = 2
                },
                new UserData
                {
                    Name = "Ramesh",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Gray,
                    EventDescription = "My Event - 3",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 00, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 01, 00, 0),
                    UserId = 3
                },
                new UserData
                {
                    Name = "Umesh",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Yellow,
                    EventDescription = "My Event - 4",
                    EventStartTime = new DateTime(2019, 8, 30, 8, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 9, 45, 0),
                    UserId = 4
                },
                new UserData
                {
                    Name = "Yogesh",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Red,
                    EventDescription = "My Event - 4",
                    EventStartTime = new DateTime(2019, 8, 30, 18, 00, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 19, 00, 0),
                    UserId = 5
                },
                new UserData
                {
                    Name = "Shyam",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Gold,
                    EventDescription = "My Event - 5",
                    EventStartTime = new DateTime(2019, 8, 30, 7, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 09, 45, 0),
                    UserId = 6
                },
                new UserData
                {
                    Name = "Vivey",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Navy,
                    EventDescription = "My Event - 6",
                    EventStartTime = new DateTime(2019, 8, 30, 11, 00, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 13, 00, 0),
                    UserId = 7
                },
                new UserData
                {
                    Name = "Rajveer",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.NavajoWhite,
                    EventDescription = "My Event - 7",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 01, 45, 0),
                    UserId = 8
                },
                new UserData
                {
                    Name = "Vinayak Kumar",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Navy,
                    EventDescription = "My Event",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 45, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 02, 00, 0),
                    UserId = 9
                },
                new UserData
                {
                    Name = "Mahesh Kumar",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Green,
                    EventDescription = "My Event - 2",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 01, 45, 0),
                    UserId = 10
                },
                new UserData
                {
                    Name = "Ramesh Kumar",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Gray,
                    EventDescription = "My Event - 3",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 00, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 01, 00, 0),
                    UserId = 11
                },
                new UserData
                {
                    Name = "Umesh Kumar",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Yellow,
                    EventDescription = "My Event - 4",
                    EventStartTime = new DateTime(2019, 8, 30, 8, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 9, 45, 0),
                    UserId = 12
                },
                new UserData
                {
                    Name = "Yogesh Kumar",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Red,
                    EventDescription = "My Event - 4",
                    EventStartTime = new DateTime(2019, 8, 30, 18, 00, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 19, 00, 0),
                    UserId = 13
                },
                new UserData
                {
                    Name = "Shyam Kumar",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Gold,
                    EventDescription = "My Event - 5",
                    EventStartTime = new DateTime(2019, 8, 30, 7, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 09, 45, 0),
                    UserId = 14
                },
                new UserData
                {
                    Name = "Vivey Kumar",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Navy,
                    EventDescription = "My Event - 6",
                    EventStartTime = new DateTime(2019, 8, 30, 11, 00, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 13, 00, 0),
                    UserId = 15
                },
                new UserData
                {
                    Name = "Rajveer Kumar",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.NavajoWhite,
                    EventDescription = "My Event - 7",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 01, 45, 0),
                    UserId = 16
                },
                new UserData
                {
                    Name = "Vinayak Sharma",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Navy,
                    EventDescription = "My Event",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 45, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 02, 00, 0),
                    UserId = 41
                },
                new UserData
                {
                    Name = "Mahesh Gupta",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Green,
                    EventDescription = "My Event - 2",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 01, 45, 0),
                    UserId = 17
                },
                new UserData
                {
                    Name = "Ramesh Sharma",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Gray,
                    EventDescription = "My Event - 3",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 00, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 01, 00, 0),
                    UserId = 18
                },
                new UserData
                {
                    Name = "Umesh",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Yellow,
                    EventDescription = "My Event - 4",
                    EventStartTime = new DateTime(2019, 8, 30, 8, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 9, 45, 0),
                    UserId = 42
                },
                new UserData
                {
                    Name = "Yogesh",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Red,
                    EventDescription = "My Event - 4",
                    EventStartTime = new DateTime(2019, 8, 30, 18, 00, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 19, 00, 0),
                    UserId = 19
                },
                new UserData
                {
                    Name = "Shyam",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Gold,
                    EventDescription = "My Event - 5",
                    EventStartTime = new DateTime(2019, 8, 30, 7, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 09, 45, 0),
                    UserId = 43
                },
                new UserData
                {
                    Name = "Vivey",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Navy,
                    EventDescription = "My Event - 6",
                    EventStartTime = new DateTime(2019, 8, 30, 11, 00, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 13, 00, 0),
                    UserId = 20
                },
                new UserData
                {
                    Name = "Rajveer",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.NavajoWhite,
                    EventDescription = "My Event - 7",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 01, 45, 0),
                    UserId = 21
                },
                new UserData
                {
                    Name = "Vinayak",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Navy,
                    EventDescription = "My Event",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 45, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 02, 00, 0),
                    UserId = 22
                },
                new UserData
                {
                    Name = "Mahesh",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.LightCyan,
                    EventDescription = "My Event - 2",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 01, 45, 0),
                    UserId = 23
                },
                new UserData
                {
                    Name = "Ramesh",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Khaki,
                    EventDescription = "My Event - 3",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 00, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 01, 00, 0),
                    UserId = 24
                },
                new UserData
                {
                    Name = "Umesh",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Yellow,
                    EventDescription = "My Event - 4",
                    EventStartTime = new DateTime(2019, 8, 30, 8, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 9, 45, 0),
                    UserId = 25
                },
                new UserData
                {
                    Name = "Yogesh",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Red,
                    EventDescription = "My Event - 4",
                    EventStartTime = new DateTime(2019, 8, 30, 18, 00, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 19, 00, 0),
                    UserId = 26
                },
                new UserData
                {
                    Name = "Shyam",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Gold,
                    EventDescription = "My Event - 5",
                    EventStartTime = new DateTime(2019, 8, 30, 7, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 09, 45, 0),
                    UserId = 27
                },
                new UserData
                {
                    Name = "Vivey",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Navy,
                    EventDescription = "My Event - 6",
                    EventStartTime = new DateTime(2019, 8, 30, 11, 00, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 13, 00, 0),
                    UserId = 28
                },
                new UserData
                {
                    Name = "Rajveer",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.NavajoWhite,
                    EventDescription = "My Event - 7",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 01, 45, 0),
                    UserId = 29
                },
                new UserData
                {
                    Name = "Vinayak",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Navy,
                    EventDescription = "My Event",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 45, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 02, 00, 0),
                    UserId = 30
                },
                new UserData
                {
                    Name = "Mahesh",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Green,
                    EventDescription = "My Event - 2",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 01, 45, 0),
                    UserId = 31
                },
                new UserData
                {
                    Name = "Ramesh",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Gray,
                    EventDescription = "My Event - 3",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 00, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 01, 00, 0),
                    UserId = 32
                },
                new UserData
                {
                    Name = "Umesh",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Yellow,
                    EventDescription = "My Event - 4",
                    EventStartTime = new DateTime(2019, 8, 30, 8, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 9, 45, 0),
                    UserId = 33
                },
                new UserData
                {
                    Name = "Yogesh",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Red,
                    EventDescription = "My Event - 4",
                    EventStartTime = new DateTime(2019, 8, 30, 18, 00, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 19, 00, 0),
                    UserId = 34
                },
                new UserData
                {
                    Name = "Shyam",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Gold,
                    EventDescription = "My Event - 5",
                    EventStartTime = new DateTime(2019, 8, 30, 7, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 09, 45, 0),
                    UserId = 35
                },
                new UserData
                {
                    Name = "Vivey",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Navy,
                    EventDescription = "My Event - 6",
                    EventStartTime = new DateTime(2019, 8, 30, 11, 00, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 13, 00, 0),
                    UserId = 36
                },
                new UserData
                {
                    Name = "Rajveer",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.NavajoWhite,
                    EventDescription = "My Event - 7",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 01, 45, 0),
                    UserId = 37
                },
                new UserData
                {
                    Name = "Vinayak",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Navy,
                    EventDescription = "My Event",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 45, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 02, 00, 0),
                    UserId = 38
                },
                new UserData
                {
                    Name = "Mahesh",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Green,
                    EventDescription = "My Event - 2",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 15, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 01, 45, 0),
                    UserId = 39
                },
                new UserData
                {
                    Name = "Ramesh",
                    UserPhoto = File.ReadAllBytes("D:\\Mukesh Jangir\\WPFSchedular\\user.PNG"),
                    EventColor = Colors.Gray,
                    EventDescription = "My Event - 3",
                    EventStartTime = new DateTime(2019, 8, 30, 0, 00, 0),
                    EventEndTime = new DateTime(2019, 8, 30, 01, 00, 0),
                    UserId = 40
                }
            };
            OnPropertyChanged("ItemsList");

            ViewSource = new CollectionViewSource
            {
                Source = ItemsList
            };

            //StaffScheduleDataGrid.ItemsSource = ItemsList;
            //DataContext = this;
            ViewSource.View.Refresh();
            //ViewSource.View.CollectionChanged += View_CollectionChanged;
            DataContext = this;
        }


        #region [INotifyPropertyChanged]

        protected virtual void SetProperty<T>(ref T member, T val, [CallerMemberName] string propertyName = null)
        {
            if (object.Equals(member, val)) return;

            member = val;
            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        public event PropertyChangedEventHandler PropertyChanged = delegate { };

        // Very minimal implementation of INotifyPropertyChanged matching msdn
        // Note that this is dependent on .net 4.5+ because of CallerMemberName
        public event PropertyChangedEventHandler PropertyChangedII;
        public void RaisePropertyChanged([CallerMemberName] String propertyName = "")
        {
            if (PropertyChangedII != null)
            {
                PropertyChangedII(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        #endregion

        /// <summary>
        /// Schedular Control User row mouse left button Up event handlar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StaffScheduleControl_on_Click(object sender, RoutedEventArgs e)
        {            

            if (e.OriginalSource is DataGridCell currentCell)
            {
                /*
                _receivedData[0] => User Id
                _receivedData[1] => Event Color
                _receivedData[2] => End Start Time (01:15-01:30 => return 00:15 value i.e.'75')
                _receivedData[3] => Start Time
                _receivedData[4] => Existing Event Start Time
                _receivedData[5] => Existing Event End Time
                _receivedData[6] => End Time
                */

                object[] _receivedData = (object[])currentCell.Tag;
                TxtUserId.Text = _receivedData[0].ToString();



                //Start Time
                int StartMinutes = Convert.ToInt16(_receivedData[3]);
                int EndMinutes = Convert.ToInt16(_receivedData[6]);

                if (StartMinutes > EndMinutes)
                {
                    //Swap start & end time
                    StartMinutes = StartMinutes + EndMinutes;
                    EndMinutes = StartMinutes - EndMinutes;
                    StartMinutes = StartMinutes - EndMinutes;
                }

                int sMinutes = StartMinutes % 60;
                int sHours = StartMinutes / 60;

                TxtStartTime.Text = sHours.ToString().PadLeft(2, '0') + ":" + sMinutes.ToString().PadLeft(2, '0');

                //End Time                
                int eMinutes = EndMinutes % 60;
                int eHours = EndMinutes / 60;

                TxtEndTime.Text = eHours.ToString().PadLeft(2, '0') + ":" + eMinutes.ToString().PadLeft(2, '0');

                var point = GetMousePosition();
                EventChildWindow.Left = (point.X - EventChildWindow.Width) > 0 ? ((point.X - EventChildWindow.Width) + EventChildWindow.Width / 2) : point.X;
                EventChildWindow.Top = point.Y;
                EventChildWindow.Show();



                //SelectedUserData.EventEndTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, eHours, eMinutes, 0);
                //SelectedUserData.EventStartTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, sHours, sMinutes, 0);

                var item = ItemsList.FirstOrDefault(i => i.UserId == Convert.ToInt16(_receivedData[0]));
                if (item != null)
                {
                    item.EventEndTime = (EndMinutes == 1440) ? new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0).AddDays(1) : new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, eHours, eMinutes, 0);
                    item.EventStartTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, sHours, sMinutes, 0);
                    //item.EventColor = Colors.NavajoWhite;
                }

                //ItemsList.Add(new UserData {
                //    UserId = 44,
                //    Name = "Test"
                //});


                OnPropertyChanged("ItemsList");
                StaffScheduleDataGrid.Items.Refresh();

                //OnPropertyChanged("ViewSource.Source");

                //ViewSource.View.Refresh();

                //StaffScheduleDataGrid.ItemsSource = null;
                //StaffScheduleDataGrid.ItemsSource = ItemsList;

                //StaffScheduleDataGrid.Dispatcher.BeginInvoke(new Action(() => StaffScheduleDataGrid.Items.Refresh()), System.Windows.Threading.DispatcherPriority.DataBind);

                //StaffScheduleDataGrid.Items.Refresh();

                //StaffScheduleDataGrid.UpdateLayout();

                //CollectionViewSource.GetDefaultView(StaffScheduleDataGrid.ItemsSource).Refresh();
            }

        }

        /// <summary>
        /// Drag existing event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StaffScheduleDataGrid_OnDragControlMouseLeftButtonUp(object sender, RoutedEventArgs e)
        {
            try
            {
                if (e.OriginalSource is object[])
                {
                    /*
                    _receivedData[0] => User Id
                    _receivedData[1] => Event Color
                    _receivedData[2] => End Start Time (01:15-01:30 => return 01:15 value i.e.'75')
                    _receivedData[3] => Start Time
                    _receivedData[4] => Existing Event Start Time
                    _receivedData[5] => Existing Event End Time
                    _receivedData[6] => End Time
                    */

                    DataGridCell dragStartCell = ((object[])e.OriginalSource)[0] as DataGridCell;
                    DataGridCell targetCell = ((object[])e.OriginalSource)[1] as DataGridCell;


                    object[] _receivedDragStartData = (object[])dragStartCell.Tag;
                    object[] _receivedTargetData = (object[])targetCell.Tag;

                    DateTime.TryParse((_receivedDragStartData[4] ?? "").ToString(), CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal | DateTimeStyles.AllowWhiteSpaces, out DateTime existingStartDate);
                    DateTime.TryParse((_receivedDragStartData[5] ?? "").ToString(), CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal | DateTimeStyles.AllowWhiteSpaces, out DateTime existingEndDate);

                    var item = ItemsList.FirstOrDefault(i => i.UserId == Convert.ToInt16(_receivedDragStartData[0]));
                    if (item != null)
                    {
                        item.EventEndTime = null;
                        item.EventStartTime = null;
                    }
                    OnPropertyChanged(nameof(ItemsList));

                    if (existingStartDate != null && existingEndDate != null)
                    {
                        //End Time
                        //int EndMinutes = Convert.ToInt16(_receivedTargetData[2]);
                        //Start Time
                        //int StartMinutes = EndMinutes - Convert.ToInt16(existingEndDate.Subtract(existingStartDate).TotalMinutes);

                        //if (StartMinutes < 0)
                        //{
                        //    StartMinutes = 0;
                        //    EndMinutes = Convert.ToInt16(existingEndDate.Subtract(existingStartDate).TotalMinutes);
                        //}

                        //Start Time
                        int StartMinutes = Convert.ToInt16(_receivedTargetData[2]) - 15;
                        StartMinutes = (StartMinutes < 0) ? 0 : StartMinutes;
                        //End Time
                        int EndMinutes = StartMinutes + Convert.ToInt16(existingEndDate.Subtract(existingStartDate).TotalMinutes);

                        if (EndMinutes >= 1440)
                        {
                            EndMinutes = 1440;
                            StartMinutes = EndMinutes - Convert.ToInt16(existingEndDate.Subtract(existingStartDate).TotalMinutes);
                        }

                        int eMinutes = EndMinutes % 60;
                        int eHours = (EndMinutes == 1440) ? 0 : EndMinutes / 60;
                        int sMinutes = StartMinutes % 60;
                        int sHours = StartMinutes / 60;

                        var itemTarget = ItemsList.FirstOrDefault(i => i.UserId == Convert.ToInt16(_receivedTargetData[0]));
                        if (itemTarget != null)
                        {
                            itemTarget.EventStartTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, sHours, sMinutes, 0);
                            itemTarget.EventEndTime = (EndMinutes == 1440) ? new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0).AddDays(1) : new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, eHours, eMinutes, 0);
                        }
                    }
                    
                    OnPropertyChanged(nameof(ItemsList));
                    StaffScheduleDataGrid.Items.Refresh();

                    //ViewSource.View.Refresh();

                    //StaffScheduleDataGrid.ItemsSource = null;
                    //StaffScheduleDataGrid.ItemsSource = ItemsList;

                    //StaffScheduleDataGrid.Items.Refresh();
                    //StaffScheduleDataGrid.UpdateLayout();

                    //CollectionViewSource.GetDefaultView(StaffScheduleDataGrid.ItemsSource).Refresh();

                }
                else
                {
                    OnPropertyChanged(nameof(ItemsList));
                    StaffScheduleDataGrid.Items.Refresh();

                    //ViewSource.View.Refresh();

                    //StaffScheduleDataGrid.ItemsSource = null;
                    //StaffScheduleDataGrid.ItemsSource = ItemsList;

                    //CollectionViewSource.GetDefaultView(StaffScheduleDataGrid.ItemsSource).Refresh();
                }
            }
            catch {
                OnPropertyChanged(nameof(ItemsList));
                StaffScheduleDataGrid.Items.Refresh();

                //ViewSource.View.Refresh();

                //StaffScheduleDataGrid.ItemsSource = null;
                //StaffScheduleDataGrid.ItemsSource = ItemsList;

                //CollectionViewSource.GetDefaultView(StaffScheduleDataGrid.ItemsSource).Refresh();
            }
        }
    }    
}
