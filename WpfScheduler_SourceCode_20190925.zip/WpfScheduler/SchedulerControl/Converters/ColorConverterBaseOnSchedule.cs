﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;

namespace SchedulerControl.Converters
{
    /// <summary>
    /// Convert color if event exist
    /// </summary>
    public class ColorConverterBaseOnSchedule : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (values != null)
            {
                if (!DateTime.TryParse((values[0] ?? "").ToString(), CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal | DateTimeStyles.AllowWhiteSpaces, out DateTime sDate))
                {
                    return new SolidColorBrush(Colors.Transparent);
                }
                if (!DateTime.TryParse((values[1] ?? "").ToString(), CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal | DateTimeStyles.AllowWhiteSpaces, out DateTime eDate))
                {
                    return new SolidColorBrush(Colors.Transparent);
                }
                int borderMinute = System.Convert.ToInt32(values[3].ToString());

                eDate = eDate.AddMinutes(-15);
                if (((sDate.Minute + (sDate.Hour * 60)) <= borderMinute) && ((eDate.Minute + (eDate.Hour * 60)) >= borderMinute))
                {
                    return new SolidColorBrush((Color)values[2]);
                }
                return new SolidColorBrush(Colors.Transparent);
            }
            return new SolidColorBrush(Colors.Transparent);
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            return null;
        }
    }


    /// <summary>
    /// Set Cursor type
    /// </summary>
    public class SetCursorTypePointer : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (values != null)
            {
                if (!DateTime.TryParse((values[0] ?? "").ToString(), CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal | DateTimeStyles.AllowWhiteSpaces, out DateTime sDate))
                {
                    return Cursors.Arrow;
                }
                if (!DateTime.TryParse((values[1] ?? "").ToString(), CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal | DateTimeStyles.AllowWhiteSpaces, out DateTime eDate))
                {
                    return Cursors.Arrow;
                }
                int borderMinute = System.Convert.ToInt32(values[3].ToString());

                eDate = eDate.AddMinutes(-15);
                if (((sDate.Minute + (sDate.Hour * 60)) <= borderMinute) && ((eDate.Minute + (eDate.Hour * 60)) >= borderMinute))
                {
                    if((((sDate.Minute + (sDate.Hour * 60)) == borderMinute) || ((eDate.Minute + (eDate.Hour * 60)) == borderMinute)))
                        return Cursors.SizeWE; //return Cursors.SizeWE;Arrow
                    else
                        return Cursors.Hand;//return Cursors.Hand;Arrow
                }
                return Cursors.Arrow;
            }
            return Cursors.Arrow;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }


    /// <summary>
    /// Check whether event already exists
    /// </summary>
    public class CheckWhetherEventAlreadyExists : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (values != null)
            {
                if (!DateTime.TryParse((values[0] ?? "").ToString(), CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal | DateTimeStyles.AllowWhiteSpaces, out DateTime sDate))
                {
                    return false;
                }
                if (!DateTime.TryParse((values[1] ?? "").ToString(), CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal | DateTimeStyles.AllowWhiteSpaces, out DateTime eDate))
                {
                    return false;
                }
                int borderMinute = System.Convert.ToInt32(values[3].ToString());

                eDate = eDate.AddMinutes(-15);
                if (((sDate.Minute + (sDate.Hour * 60)) <= borderMinute) && ((eDate.Minute + (eDate.Hour * 60)) >= borderMinute))
                {
                    return true;
                }
                return false;
            }
            return false;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    /// <summary>
    /// Hide Border tooltip (If Event Already exist)
    /// </summary>
    public class BorderToolTipVisibilityConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (values != null)
            {
                if (!DateTime.TryParse((values[0] ?? "").ToString(), CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal | DateTimeStyles.AllowWhiteSpaces, out DateTime sDate))
                {
                    return Visibility.Visible;
                }
                if (!DateTime.TryParse((values[1] ?? "").ToString(), CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal | DateTimeStyles.AllowWhiteSpaces, out DateTime eDate))
                {
                    return Visibility.Visible;
                }
                int borderMinute = System.Convert.ToInt32(values[3].ToString().Split('_')[1]);
                
                if (((sDate.Minute + (sDate.Hour * 60)) <= borderMinute) && ((eDate.Minute + (eDate.Hour * 60)) >= borderMinute))
                {
                    return Visibility.Collapsed;
                }
                return Visibility.Visible;
            }
            return Visibility.Visible;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    /// <summary>
    /// DataGrid Border Column width converter
    /// </summary>
    public class DataGridColumnWidthConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value != null)
            {
                int.TryParse(value.ToString(), out int totalWidth);
                if (totalWidth == 0)
                    totalWidth = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width;

                return System.Convert.ToDouble((totalWidth - 150) / 96);
            }
            return 0;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return value!=null ? parameter : null;
        }
    }

    /// <summary>
    /// Multivalue Converter for Border Tag
    /// </summary>
    public class BorderTagMultiValueConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return values.Clone();
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            return null;
        }
    }
}
